from django.apps import AppConfig


class ClassificationsConfig(AppConfig):
    name = 'label_ai.classifications'
