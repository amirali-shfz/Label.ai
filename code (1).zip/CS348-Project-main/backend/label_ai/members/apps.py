from django.apps import AppConfig


class MembersConfig(AppConfig):
    name = 'label_ai.members'
