from django.apps import AppConfig


class ImagesConfig(AppConfig):
    name = 'label_ai.images'
