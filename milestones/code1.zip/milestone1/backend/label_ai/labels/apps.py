from django.apps import AppConfig


class LabelsConfig(AppConfig):
    name = 'label_ai.labels'
